# Worktree Desk — Project Planning Bundle

**Status:** Revised scope-of-work and architecture baseline  
**Starting implementation path:** Electrobun + React + TypeScript  
**Supported fallback path:** Electron + React + TypeScript, used only if an Electrobun capability gate fails  
**Product purpose:** A local desktop application for managing multiple Git projects, their linked worktrees, and safe shared local-development resources such as `.env` files and certificates.

## Decision update — June 4, 2026

The project is no longer defined around Electron. It is defined around a portable product core and two desktop-shell adapters:

1. Start development with **Electrobun**, using Bun in the privileged process and React/TypeScript in the UI.
2. Keep **Electron** as a deliberately preserved fallback, without redesigning the domain layer or UI.
3. Do not migrate because of a minor integration inconvenience. Migrate only when a required MVP capability cannot be implemented reliably or safely in Electrobun.

Electrobun is treated as a legitimate starting platform rather than an experiment-only option because its official documentation describes a TypeScript desktop framework with a Bun main process, native/system webviews with optional CEF, typed RPC, native dialogs/utilities, and packaging/update support. Its GitHub release history listed stable `v1.18.1` on May 4, 2026 when this revision was prepared.

## Documents

| Document | Purpose |
|---|---|
| `00-decision-and-project-plans.md` | Updated Electrobun-first decision and Electron fallback plan |
| `01-product-scope-sow.md` | Definitive product scope, releases, exclusions, and acceptance criteria |
| `02-technical-architecture.md` | Portable architecture, Git parsing, shell adapters, errors and resources |
| `03-ui-ux-specification.md` | Shell-independent screens, workflows and component behavior |
| `04-implementation-roadmap-tools-and-skills.md` | Electrobun-first setup, packages, testing, skills and roadmap |
| `05-electrobun-validation-and-electron-fallback.md` | Capability gate and migration contract |

## Selected MVP outcome

The initial release must allow a developer to:

1. Register multiple local Git repositories without duplicating the same repository when a linked worktree is selected.
2. View and manage every linked worktree in each repository.
3. Create, open, lock, unlock, move, remove, repair, and prune-preview worktrees through a safe UI.
4. Define shared-resource profiles and symlink ignored files such as `.env` into newly created worktrees.
5. Preserve raw Git failures and explain recognized errors with practical remediation steps.
6. Avoid unsafe defaults, especially direct sharing of a writable `node_modules` directory.

## Core decision summary

| Decision | Selection |
|---|---|
| Initial desktop shell | Electrobun |
| Fallback desktop shell | Electron |
| UI | React + TypeScript; shell-independent feature layer |
| Styling/UI | Tailwind CSS + shadcn/ui/Radix primitives |
| Privileged runtime — initial | Bun process provided by Electrobun |
| Git command execution — initial | `Bun.spawn()` behind a `CommandRunner` interface |
| Git command execution — fallback | `execa`/Node.js behind the same interface |
| UI-to-privileged bridge — initial | Electrobun typed RPC |
| UI-to-privileged bridge — fallback | Electron preload/IPC adapter |
| Git parsing | Custom typed parsers over Git machine output (`--porcelain`, `--porcelain=v2`, `-z`) |
| Validation | Zod |
| State/persistence | Zustand for UI state; versioned JSON configuration for MVP |
| Dependency sharing | Per-worktree install using package-manager storage; no direct `node_modules` link by default |
| First supported environment | macOS; architecture must not prevent later Windows/Linux support |

## References

Official Electrobun references added in this revision:

- https://docs.electrobunny.ai/electrobun/
- https://docs.electrobunny.ai/electrobun/guides/quick-start/
- https://docs.electrobunny.ai/electrobun/guides/architecture/overview/
- https://docs.electrobunny.ai/electrobun/apis/browser-view/
- https://docs.electrobunny.ai/electrobun/apis/utils/
- https://github.com/blackboardsh/electrobun/releases
- https://bun.com/docs/runtime/child-process

A complete bibliography is included in `04-implementation-roadmap-tools-and-skills.md`.
