# 00 — Decision and Project Plans

## 1. Revised decision

Build **Worktree Desk** with an **Electrobun-first, Electron-compatible** architecture.

The product should not be coupled to either shell. The UI, Git parsers, domain services, validation rules, error model, resource profiles and operation journal are product code. Electrobun or Electron should only supply a thin desktop boundary: window lifecycle, privileged command/filesystem execution, native dialogs, app launching, persistence path discovery and UI-to-backend messaging.

### Starting path

**Electrobun + React + TypeScript** is the starting implementation.

Why this is reasonable now:

- Electrobun's official documentation describes a Bun-backed TypeScript desktop application framework using the system's native WebView by default, with CEF optional when Chromium consistency is needed.
- The framework documents typed RPC between the browser UI and Bun process.
- Its documented utilities cover selecting files/folders, message boxes, opening paths, revealing files and clipboard/system interactions needed by this product.
- Its release history listed a stable `v1.18.1` release on May 4, 2026.

### Fallback path

**Electron + React + TypeScript** remains a maintained fallback design.

Move to Electron only if an Electrobun spike or later implementation establishes a critical blocker, such as failure to safely run/stream Git operations, create required filesystem links, support the needed React UI reliably, package the application for daily macOS use, or keep the privileged/UI boundary maintainable.

## 2. Non-negotiable portable product rules

These do not change when the desktop shell changes:

1. Do not parse normal human-readable terminal output.
2. Execute Git through a `CommandRunner` abstraction using argument arrays.
3. Read Git's documented machine formats:
   - `git worktree list --porcelain -z`
   - `git status --porcelain=v2 --branch -z`
   - `git for-each-ref --format=...`
   - `git check-ignore --stdin -v -z`
4. Keep React features independent of Electrobun and Electron APIs.
5. Keep privileged filesystem/process operations behind a typed, validated `DesktopBridge`.
6. Store paths and rules, never secret file contents.
7. Never offer a shared writable `node_modules` symlink as normal behavior.
8. Preserve raw sanitized technical failure details.

## 3. Platform plans

### Plan A — Electrobun + React + TypeScript — Start here

#### Role

Primary initial implementation path for v0.1.

#### Stack

| Area | Selection |
|---|---|
| Shell/runtime | Electrobun with Bun privileged process |
| UI | React + TypeScript, loaded as a bundled view |
| Web rendering | Native system WebView initially; evaluate optional CEF only when renderer consistency requires it |
| UI/backend communication | Electrobun typed RPC |
| Git/process runner | `Bun.spawn()` implementation of `CommandRunner` |
| Filesystem/symlinks | Bun-compatible TypeScript filesystem code behind `ResourceFilesystem` |
| Dialogs/open/reveal | Electrobun `Utils` adapter |
| Packaging/distribution | Electrobun build/distribution tooling |
| Validation | Zod |
| UI state | Zustand |
| Unit tests | Vitest or Bun-compatible test setup; parser tests are runtime-independent |
| Integration tests | Real Git repositories in temporary folders |

#### Benefits

- Keeps the implementation in TypeScript/JavaScript while avoiding a Chromium-bundled application by default.
- Bun is already the privileged runtime, making subprocess operations such as Git execution natural through `Bun.spawn()`.
- Official APIs cover typed RPC and native utility operations required by the MVP.
- Desktop distribution, signing/update concerns are part of Electrobun's documented framework scope.

#### Risks to validate immediately

- React/Tailwind/shadcn rendering consistency under the chosen native WebView on macOS.
- Streaming Git/setup output into the operation center.
- Symlink creation/repair and filesystem permission behavior.
- Launching Cursor/VS Code/terminal reliably.
- Test strategy for Bun subprocess capture and packaged application execution.
- Whether optional CEF is needed to avoid UI behavior variance.

#### Rule

Do not import Electrobun APIs in product feature modules. Only the adapter layer may depend on `electrobun/bun` or `electrobun/view`.

---

### Plan B — Electron + React + TypeScript — Preserved fallback

#### Role

Fallback when an Electrobun blocker affects MVP reliability, security or maintenance.

#### Stack

| Area | Selection |
|---|---|
| Shell/runtime | Electron + Node.js main process |
| UI | Same React + TypeScript feature code |
| UI/backend communication | Preload bridge + validated IPC implementing `DesktopBridge` |
| Git/process runner | `execa` implementation of `CommandRunner` |
| Filesystem/symlinks | Node filesystem adapter implementing the same interface |
| Packaging | Electron Forge or equivalent evaluated during migration |

#### Benefits

- Broad Node/npm ecosystem compatibility.
- Chromium rendering consistency.
- Mature patterns for filesystem/process-heavy desktop utilities.

#### Cost

- Larger runtime and application footprint.
- Migration effort in the desktop adapter, packaging and tests.

#### Rule

A fallback migration must not rewrite Git parsers, domain models, resource-policy logic, error classification, or most React UI components.

## 4. Migration-resilient boundaries

```text
React feature UI
  │
  │ DesktopClient interface
  ▼
Bridge Adapter
  ├── Electrobun typed RPC adapter     ← initial implementation
  └── Electron preload/IPC adapter      ← fallback implementation
  │
  ▼
Application services
  ├── ProjectRegistryService
  ├── GitWorktreeService
  ├── SharedResourceService
  ├── OperationJournalService
  └── ErrorInterpreter
  │
  ▼
Platform ports
  ├── CommandRunner
  │     ├── BunSpawnCommandRunner       ← initial
  │     └── ExecaCommandRunner          ← fallback
  ├── ResourceFilesystem
  ├── NativeDialogService
  └── ExternalLauncherService
```

## 5. Alternatives not currently pursued

| Option | Decision | Reason |
|---|---|---|
| Neutralinojs | Deprioritized | No longer needed as the lightweight option because Electrobun is the chosen first attempt. |
| Tauri | Not selected | Its privileged backend requires Rust, outside the intended TypeScript/JavaScript implementation path. |
| Bun local browser service | Not selected for product | Useful for experiments, but not the desired desktop interaction/distribution model. |
| Full Git GUI | Rejected for MVP | It expands scope without solving worktree setup/navigation problems. |

## 6. Product positioning

Worktree Desk is a companion to existing editors and Git clients. It owns:

- repository/worktree registration and navigation;
- worktree creation, cleanup, repair and safety;
- shared resource linking;
- setup-command execution and diagnostics;
- editor/terminal/folder launching.

It leaves commits, staging, branch graphs, rebase/merge conflict UI and remote pull-request workflows to existing tools.

## 7. Decision checkpoints

| Checkpoint | Decision |
|---|---|
| Initial scaffold | Use Electrobun + React + TypeScript |
| End of capability spike | Continue Electrobun only after all critical desktop capabilities pass |
| During MVP | Fix normal integration issues; do not migrate prematurely |
| Framework-level blocker | Create Electron adapter while preserving product core |
| Before release | Confirm chosen shell packages, signs and runs daily workflow on macOS |

## 8. Official references

- Electrobun overview: https://docs.electrobunny.ai/electrobun/
- Electrobun quick start: https://docs.electrobunny.ai/electrobun/guides/quick-start/
- Electrobun architecture: https://docs.electrobunny.ai/electrobun/guides/architecture/overview/
- Electrobun typed RPC / BrowserView: https://docs.electrobunny.ai/electrobun/apis/browser-view/
- Electrobun utilities: https://docs.electrobunny.ai/electrobun/apis/utils/
- Electrobun releases: https://github.com/blackboardsh/electrobun/releases
- Bun subprocess API: https://bun.com/docs/runtime/child-process
- Electron documentation: https://www.electronjs.org/docs/latest/
- Electron security: https://www.electronjs.org/docs/latest/tutorial/security
