# 04 — Implementation Roadmap, Tools and Skills

## 1. Platform direction

Implementation starts with **Electrobun + React + TypeScript**. The project must keep **Electron + React + TypeScript** as an adapter-level fallback.

The first implementation task is not the full product. It is the capability spike defined in `05-electrobun-validation-and-electron-fallback.md`. This prevents investing heavily in shell-specific behavior before the core desktop requirements have been validated.

## 2. Terminology: project packages vs agent skills

Two categories are relevant:

1. **Application dependencies** are packages installed in the repository to build and run Worktree Desk.
2. **Agent skills** are repository-local or installed guidance for Codex and other coding agents, used to preserve UI and architecture rules while implementing the app.

Agent skills do not replace packages or tests.

## 3. Recommended application dependency stack

### Shared dependencies

| Package/category | Purpose |
|---|---|
| `react`, `react-dom` | Shared desktop UI |
| `zod` | Validate bridge payloads, configuration and domain inputs |
| `zustand` | Lightweight UI state |
| `lucide-react` | Icon set |
| `clsx`, `tailwind-merge` | Component class composition |

### Electrobun-first dependencies/tooling

| Package/category | Purpose |
|---|---|
| `electrobun` | Initial desktop shell and Bun-side desktop APIs |
| Bun built-in `Bun.spawn()` | Initial Git/setup subprocess runner |
| `vite`, `@vitejs/plugin-react`, `typescript` | React UI build setup as required by selected scaffold |
| `tailwindcss` and shadcn/ui CLI/components | UI system |
| `vitest` or verified Bun-compatible testing setup | Domain/parser unit tests |
| `@testing-library/react` | UI component tests |
| `eslint`, `prettier` | Static quality/style |

### Electron fallback-only dependencies

Do not install these at the start unless required for a migration spike:

| Package/category | Purpose |
|---|---|
| `electron` | Fallback desktop shell |
| `@electron-forge/cli` / Forge Vite tooling | Fallback packaging/build |
| `execa` | Node-side command runner implementing the same `CommandRunner` contract |
| `playwright` Electron-specific setup | Fallback desktop end-to-end coverage |

### Optional later dependency

| Package | Introduce when |
|---|---|
| `@xterm/xterm`, `@xterm/addon-fit` | Only when a long-operation terminal-style display provides meaningful UX benefit |

## 4. Starting scaffold

### Electrobun-first bootstrap

Official Electrobun documentation uses:

```sh
bunx electrobun init
cd worktree-desk
bun install
bun start
```

Select or adapt the TypeScript UI template so the project includes a React view. After the shell launches, add shared UI/domain dependencies:

```sh
bun add react react-dom zod zustand lucide-react clsx tailwind-merge
bun add -d typescript vite @vitejs/plugin-react vitest @testing-library/react eslint prettier

bunx --bun shadcn@latest init
bunx --bun shadcn@latest add sidebar button badge card dialog alert-dialog command sheet form dropdown-menu scroll-area separator tabs tooltip table
```

The exact React bundling adjustment must be validated against the current Electrobun template and documentation during Phase 0; do not bring Electron bootstrap files into the initial project.

### Electron fallback bootstrap

Only after a documented fallback decision:

```sh
npx create-electron-app@latest worktree-desk-electron --template=vite
```

Migrate by attaching the existing `src/core` and `src/ui` code to Electron adapters, not by rewriting the application.

## 5. Repository structure

```text
worktree-desk/
├── .agents/
│   └── skills/
│       └── worktree-desk-domain/
│           └── SKILL.md
├── docs/
├── src/
│   ├── core/
│   │   ├── domain/
│   │   ├── errors/
│   │   ├── git/
│   │   │   └── parsers/
│   │   ├── schemas/
│   │   └── services/
│   ├── platform/
│   │   ├── contracts/
│   │   ├── electrobun/          # initial platform adapter
│   │   │   ├── bun-entry.ts
│   │   │   ├── bridge-rpc.ts
│   │   │   ├── bun-spawn-runner.ts
│   │   │   ├── dialog-adapter.ts
│   │   │   ├── filesystem-adapter.ts
│   │   │   └── launcher-adapter.ts
│   │   └── electron/            # added only if fallback is triggered
│   └── ui/
│       ├── components/
│       ├── features/
│       ├── screens/
│       └── main.tsx
├── tests/
│   ├── fixtures/git/
│   ├── unit/
│   ├── integration/
│   └── e2e/
└── electrobun.config.ts
```

## 6. Agent skills to install or create

### Existing UI-focused skills

```sh
npx skills add vercel-labs/agent-skills \
  --skill react-best-practices \
  --skill web-design-guidelines \
  -a codex -y
```

Optional visual-design exploration:

```sh
npx skills add https://github.com/anthropics/skills/tree/main/skills/frontend-design \
  -a codex -y
```

### Required custom project skill

Create:

```text
.agents/skills/worktree-desk-domain/SKILL.md
```

Suggested content:

```md
---
name: worktree-desk-domain
description: Apply the Worktree Desk Git worktree, resource safety, diagnostics and portable desktop-shell architecture contract when implementing or reviewing this repository.
---

# Worktree Desk domain constraints

Read `docs/01-product-scope-sow.md`, `docs/02-technical-architecture.md`, and `docs/05-electrobun-validation-and-electron-fallback.md` before feature changes.

Platform decision:
- Start in Electrobun + React + TypeScript.
- Preserve Electron as an adapter-level fallback only.
- Keep product core and React features free from framework-specific imports.

Mandatory rules:
- Execute Git using argument arrays through `CommandRunner`; do not interpolate shell strings.
- Initial command runner is `Bun.spawn()` in the Electrobun Bun process.
- If Electron fallback is formally triggered, add an `execa` adapter implementing the same contract.
- Parse only documented Git machine output: porcelain/v2/NUL-delimited formats.
- Expose only typed, validated bridge operations to UI code.
- Block secret-resource links unless the target is Git-ignored.
- Never introduce direct shared writable node_modules as a standard feature.
- Preserve raw sanitized stderr/exit-code diagnostics for failed operations.
- Distinguish partial success: a created worktree remains visible even if setup fails.

Before completing a change:
- Add or update parser/classifier tests.
- Add or update Git/filesystem mutation integration coverage.
- State any modification to MVP scope or platform fallback criteria.
```

## 7. Implementation phases

### Phase 0 — Electrobun capability spike

Deliverables:

- Electrobun TypeScript application with React UI.
- Typed RPC boundary between React view and Bun privileged services.
- `BunSpawnCommandRunner` for `git --version`, worktree listing and status.
- Native directory picker and workspace-opening proof.
- `.env` ignored-target check and test symlink setup.
- Operation/error detail UI.
- Packaged macOS vertical slice.
- Written pass/fail result against the capability gate.

Exit criteria:

- Every blocking item in `05-electrobun-validation-and-electron-fallback.md` passes, or the Electron fallback is formally documented.

### Phase 1 — Project registry and read-only worktree inventory

Deliverables:

- Add/remove registered project.
- Resolve repository common directory.
- Prevent duplicate registration through linked worktrees.
- Typed parsers for `git worktree list --porcelain -z` and `git status --porcelain=v2 --branch -z`.
- Worktree board with clean/modified/locked/prunable states.

Exit criteria:

- Multiple repositories persist and reload.
- Parser fixture tests pass for edge-case paths/statuses.
- Worktree paths open through the selected desktop adapter.

### Phase 2 — Safe worktree mutations

Deliverables:

- Create existing/new branch worktrees.
- Branch listing and preflight.
- Lock/unlock, move, repair.
- Safe remove and prune preview/execute.
- Operation journal and failure panel.

Exit criteria:

- All mutations are serialized per repository.
- Dirty-removal safeguards pass integration tests.
- Every mutation produces inspectable success/failure records.

### Phase 3 — Shared resources and setup commands

Deliverables:

- Resource profile editor.
- Symlink/copy actions.
- Git-ignore validation for protected targets.
- Link health/repair.
- Setup profile commands and streamed logs.
- Partial-success UI for setup failure.

Exit criteria:

- Ignored `.env` linking works end to end.
- Non-ignored secret links are blocked.
- Failed setup never obscures successful worktree creation.
- No secret content is stored or logged.

### Phase 4 — Product refinement and release path

Deliverables:

- Completed wizard and operation center UX.
- Loading/empty/error states.
- Accessibility and keyboard review.
- Packaging/release checks for the selected shell.
- Daily-use validation with a real multi-worktree project.

Exit criteria:

- MVP acceptance criteria pass under Electrobun, or under Electron only after documented fallback.

## 8. Testing plan

### Shared unit tests

| Area | Focus |
|---|---|
| Worktree parser | Porcelain fields, NUL delimiters, locked/prunable states |
| Status parser | Clean/modified/untracked/conflicted and ahead/behind |
| Error interpreter | Known command/filesystem failure mapping |
| Schemas | Rejection of malformed bridge/config/resource payloads |
| Path validation | Prevent resource target traversal outside a worktree |

### Integration tests

Create temporary Git repositories and use real Git for:

- add/list/move/remove/lock/unlock/repair/prune behavior;
- duplicate registration through primary and linked-worktree paths;
- paths with spaces and Unicode;
- ignored `.env` validation and symlink setup;
- dirty worktree removal failure and explicit force removal;
- post-create setup partial failure.

### Platform tests

| Adapter | Test focus |
|---|---|
| Electrobun | Typed RPC boundary, `Bun.spawn()` output/error capture, dialogs/opening, packaged launch |
| Electron fallback, only when present | Preload/IPC parity, `execa` runner parity, packaged launch |

## 9. References

### Electrobun and Bun

- Electrobun documentation: https://docs.electrobunny.ai/electrobun/
- Electrobun quick start: https://docs.electrobunny.ai/electrobun/guides/quick-start/
- Electrobun architecture: https://docs.electrobunny.ai/electrobun/guides/architecture/overview/
- Electrobun BrowserView / typed RPC: https://docs.electrobunny.ai/electrobun/apis/browser-view/
- Electrobun utilities: https://docs.electrobunny.ai/electrobun/apis/utils/
- Electrobun releases: https://github.com/blackboardsh/electrobun/releases
- Bun child processes: https://bun.com/docs/runtime/child-process

### Git and fallback tooling

- Git worktree documentation: https://git-scm.com/docs/git-worktree
- Git status porcelain formats: https://git-scm.com/docs/git-status
- Git reference formatting: https://git-scm.com/docs/git-for-each-ref
- Git ignore checking: https://git-scm.com/docs/git-check-ignore
- execa, Electron fallback only: https://github.com/sindresorhus/execa
- Electron documentation: https://www.electronjs.org/docs/latest/
- Electron security: https://www.electronjs.org/docs/latest/tutorial/security
- Electron IPC: https://www.electronjs.org/docs/latest/tutorial/ipc

### UI and skills

- shadcn/ui: https://ui.shadcn.com/docs
- Radix Primitives: https://www.radix-ui.com/primitives
- Zod: https://zod.dev/
- OpenAI Codex skills: https://developers.openai.com/codex/skills/
- Vercel agent skills: https://github.com/vercel-labs/agent-skills
